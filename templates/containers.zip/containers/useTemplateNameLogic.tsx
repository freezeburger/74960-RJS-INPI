export const useTemplateNameLogic = () => {
    return {
        // Add your logic here
    };
}