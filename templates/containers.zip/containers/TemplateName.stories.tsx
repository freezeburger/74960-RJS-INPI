/* eslint-disable */
import TemplateName from './TemplateName';

export default {
  title: "TemplateName",
};

export const Default = () => <TemplateName />;

Default.story = {
  name: 'default',
};
