import TemplateName from "./TemplateName.lazy";
import { withTemplateNameLogic } from "./withTemplateNameLogic";

export default withTemplateNameLogic(TemplateName);