import { useTemplateNameLogic } from "./useTemplateNameLogic";

export const withTemplateNameLogic = (Component) => {

    return ((props) => {
        const logic = useTemplateNameLogic();
        return <Component logic={logic} {...props}/>
    }
}